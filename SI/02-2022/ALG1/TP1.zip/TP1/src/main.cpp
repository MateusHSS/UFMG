// C++ implementation to find if the given
// expression is satisfiable using the
// Kosaraju's Algorithm
#include <iostream>
#include <vector>
#include <stack>
using namespace std;

// adds edges to form the original graph
void addEdges(int a, int b, vector<int> *adj){
	// cout << "Add edges " << a << " -> " << b << endl;
	adj[a].push_back(b);
}

// add edges to form the inverse graph
void addEdgesInverse(int a, int b, vector<int> *adj_t)
{
	// cout << "Add edges inverse " << b << " -> " << a << endl;
	adj_t[b].push_back(a);
}

// for STEP 1 of Kosaraju's Algorithm
void dfsFirst(int u, bool *visitados, vector<int> *adj, stack<int>* s){
	if(visitados[u]) return;

	visitados[u] = 1;

	for (int i=0;i<adj[u].size();i++)
		dfsFirst(adj[u][i], visitados, adj, s);

	s->push(u);
}

// for STEP 2 of Kosaraju's Algorithm
void dfsSecond(int u, bool *visitados_t, vector<int> *adj_t, int *comp_fort_con, int contador_comp){
	if(visitados_t[u])
		return;

	visitados_t[u] = 1;

	for (int i=0;i<adj_t[u].size();i++)
		dfsSecond(adj_t[u][i], visitados_t, adj_t, comp_fort_con, contador_comp);

	comp_fort_con[u] = contador_comp;
}

// function to check 2-Satisfiability
void is2Satisfiable(int n, int m, int a[], int b[])
{
	vector<int> *adj = (vector<int>*)malloc(((2*n) + 1) * sizeof(vector<int>));
	vector<int> *adj_t = (vector<int>*)malloc(((2*n) + 1) * sizeof(vector<int>));
	bool *visitados = (bool*)malloc(((2*n) + 1) * sizeof(bool));
	bool *visitados_t = (bool*)malloc(((2*n) + 1) * sizeof(bool));
	stack<int> *s = new stack<int>;
	int *comp_fort_con = (int*)malloc(((2*n)+1) * sizeof(int));
	int contador_comp = 1;

	cout << "adj INICIAL: " << endl;
	for(int i = 0; i < (n*2)+1; i++) {
		cout << i << "(tamanho: "<< adj[i].size() << "):";

		for (int j = 0; j < adj[i].size(); j++)
		{
			cout << adj[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
	// adding edges to the graph
  // adicionadno as arestas ao grafo
  // cout << "teste" << endl;
	for(int i = 0; i < m; i++){
    // variavel x eh mapeada para x
    // variavel -x eh mapeada para n+x = n-(-x)

    /*
    * para a[i] ou b[i], adiciona arestas 
    * -a[i] -> b[i] E -b[i] -> a[i]
    */
    // cout << "adicionando arestas para ("<< a[i] << ", " << b[i] << ")" << endl;
		if (a[i] > 0 && b[i] > 0){
      // cout << "primeiro if " << endl;
			addEdges(a[i]+n, b[i], adj);
			addEdgesInverse(a[i]+n, b[i], adj_t);
			addEdges(b[i]+n, a[i], adj);
			addEdgesInverse(b[i]+n, a[i], adj_t);
		}

		else if (a[i]>0 && b[i]<0)
		{
      // cout << "segundo if " << endl;
			addEdges(a[i]+n, n-b[i], adj);
			addEdgesInverse(a[i]+n, n-b[i], adj_t);
			addEdges(-b[i], a[i], adj);
			addEdgesInverse(-b[i], a[i], adj_t);
		}

		else if (a[i]<0 && b[i]>0)
		{
      // cout << "terceiro if " << endl;
			addEdges(-a[i], b[i], adj);
			addEdgesInverse(-a[i], b[i], adj_t);
			addEdges(b[i]+n, n-a[i], adj);
			addEdgesInverse(b[i]+n, n-a[i], adj_t);
		}
    else if (a[i] == 0) {
      // cout << "quarto if " << endl;
      if(b[i] < 0){
        addEdges(-b[i], n-b[i], adj);
        addEdgesInverse(-b[i], n-b[i], adj_t);
      }else if(b[i] > 0) {
        addEdges(b[i], b[i]+n, adj);
        addEdgesInverse(b[i], b[i]+n, adj_t);
      }
    }
    else if(b[i] == 0){
      // cout << "quinto if " << endl;
      // cout << "ZERO AQUIIIIII" << endl;
      if(a[i] < 0){
        addEdges(-a[i], n-a[i], adj);
        addEdgesInverse(-a[i], n-a[i], adj_t);
      }else if(a[i] > 0){
        addEdges(a[i]+n, a[i], adj);
        addEdgesInverse(a[i]+n, a[i], adj_t);
      }

      // cout << "PASSSOUUUU" << endl;
    }
		else
		{
      // cout << "ultimo if " << endl;
			addEdges(-a[i], n-b[i], adj);
			addEdgesInverse(-a[i], n-b[i], adj_t);
			addEdges(-b[i], n-a[i], adj);
			addEdgesInverse(-b[i], n-a[i], adj_t);
		}
	}

	// STEP 1 of Kosaraju's Algorithm which
	// traverses the original graph
	for (int i=1;i<=(2*n);i++)
		if (!visitados[i])
			dfsFirst(i, visitados, adj, s);

	// STEP 2 of Kosaraju's Algorithm which
	// traverses the inverse graph. After this,
	// array scc[] stores the corresponding value
	while (!s->empty())
	{
		int n = s->top();
		s->pop();

		if (!visitados_t[n])
		{
			dfsSecond(n, visitados_t, adj_t, comp_fort_con, contador_comp);
			contador_comp++;
		}
	}

	for (int i = 1; i <= n; i++){
		// for any 2 variable x and -x lie in
		// same SCC
		// cout << "comparando as componentes de " << i << ": " << comp_fort_con[i] << "e" << i+n << ": " << comp_fort_con[i+n] << endl;
		if(comp_fort_con[i]==comp_fort_con[i+n]){
			// cout << (comp_fort_con[i]==comp_fort_con[i+n]) << endl;
			cout << "nao" << endl;
			return;
		}
	}

	// no such variables x and -x exist which lie
	// in same SCC
	cout << "sim" << endl;

	cout << "adj FINAL: " << endl;
	for(int i = 0; i < (n*2)+1; i++) {
		cout << i << ": ";

		for (int j = 0; j < adj[i].size(); j++)
		{
			cout << adj[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;

	free(adj);
	free(adj_t);
	free(visitados);
	free(visitados_t);
	return;
}

// Driver function to test above functions
int main()
{
	int num_seguidores;
    int num_propostas;
    while(cin >> num_seguidores >> num_propostas){

			if(num_seguidores == 0 && num_propostas == 0) return 0;
      // vector<int> literal_um, literal_dois;
      // int literal_um[num_seguidores], literal_dois[num_seguidores];
      int* literal_um = (int*)malloc((num_seguidores * 2) * sizeof(int));
      int* literal_dois = (int*)malloc((num_seguidores * 2) * sizeof(int));
      int aux = 0;

      for (int i = 0; i < num_seguidores; i++){
        int voto_a_favor_um, voto_a_favor_dois;

        cin >> voto_a_favor_um;

        // literal_um.push_back(voto_a_favor_um);
        literal_um[aux] = voto_a_favor_um;

        cin >> voto_a_favor_dois;

        // literal_dois.push_back(voto_a_favor_dois);
        literal_dois[aux] = voto_a_favor_dois;

        aux++;

        int voto_contra_um, voto_contra_dois;

        cin >> voto_contra_um;

        // literal_um.push_back(-voto_contra_um);
        literal_um[aux] = -voto_contra_um;

        cin >> voto_contra_dois;

        // literal_dois.push_back(-voto_contra_dois);
        literal_dois[aux] = -voto_contra_dois;

        aux++;
      }    

      is2Satisfiable(num_propostas, num_seguidores*2, literal_um, literal_dois);
    }
}
