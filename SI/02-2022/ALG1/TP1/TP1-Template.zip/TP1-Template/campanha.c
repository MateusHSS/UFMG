#include <stdio.h>
#include <stdlib.h>
#include "campanha.h"

void test(){
    printf("It works!\n");
}
