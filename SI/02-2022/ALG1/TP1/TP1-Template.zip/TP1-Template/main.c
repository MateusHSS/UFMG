#include <stdio.h>
#include <stdlib.h>
#include "campanha.h"

int main() {
  // call a function in another file
  test();

  return(0);
}
