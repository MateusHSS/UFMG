#include "graph.hpp"
#include <iostream>

using namespace std;

Graph::Graph(int num_vertices) {
    // Your code here
}
