#ifndef GRAPH_HPP
#define GRAPH_HPP

#include <vector>

class Graph {
public:
    Graph(int num_vertices);
    // Your code here
};

#endif // GRAPH_HPP